DROP TABLE TB_XDR_IFC_UU;

CREATE TABLE TB_XDR_IFC_UU (
      PARENTXDRID                   VARCHAR2(32),
      LENGTH                        NUMBER(11),
      CITY                          VARCHAR2(10),
      INTERFACE                     NUMBER(3),
      XDRID                         VARCHAR2(32),
      RAT                           NUMBER(3),      
      IMSI                          VARCHAR2(16),
      IMEI                          VARCHAR2(16),
      MSISDN                        VARCHAR2(32),
      PROCEDURETYPE                 NUMBER(3),
      PROCEDURESTARTTIME            NUMBER(20), -- DATE,
      PROCEDUREENDTIME              NUMBER(20), -- DATE,
      KEYWORD1                      NUMBER(3),
      KEYWORD2                      NUMBER(3),
      PROCEDURESTATUS               NUMBER(3),
      PLMNID                        VARCHAR2(20),
      ENBID                         NUMBER(11),
      CELLID                        NUMBER(11),
      CRNTI                         NUMBER(11),
      TARGETENBID                   NUMBER(11),
      TARGETCELLID                  NUMBER(11),
      TARGETCRNTI                   NUMBER(11),
      MMEUES1APID                   NUMBER(11),
      MMEGROUPID                    NUMBER(11),
      MMECODE                       NUMBER(11),
      MTMSI                         NUMBER(11),
      CSFBINDICATION                NUMBER(11),
      REDIRECTEDNETWORK             NUMBER(11),
      EPSBEARERNUMBER               NUMBER(3),
      BEARER0ID                     NUMBER(11),
      BEARER0STATUS                 NUMBER(11),
      BEARER1ID                     NUMBER(11),
      BEARER1STATUS                 NUMBER(11),
      BEARER2ID                     NUMBER(11),
      BEARER2STATUS                 NUMBER(11),
      BEARER3ID                     NUMBER(11),
      BEARER3STATUS                 NUMBER(11),
      BEARER4ID                     NUMBER(11),
      BEARER4STATUS                 NUMBER(11),
      BEARER5ID                     NUMBER(11),
      BEARER5STATUS                 NUMBER(11),
      BEARER6ID                     NUMBER(11),
      BEARER6STATUS                 NUMBER(11),
      BEARER7ID                     NUMBER(11),
      BEARER7STATUS                 NUMBER(11),
      BEARER8ID                     NUMBER(11),
      BEARER8STATUS                 NUMBER(11),
      BEARER9ID                     NUMBER(11),
      BEARER9STATUS                 NUMBER(11),
      BEARER10ID                     NUMBER(11),
      BEARER10STATUS                 NUMBER(11),
      BEARER11ID                     NUMBER(11),
      BEARER11STATUS                 NUMBER(11),
      BEARER12ID                     NUMBER(11),
      BEARER12STATUS                 NUMBER(11),
      BEARER13ID                     NUMBER(11),
      BEARER13STATUS                 NUMBER(11),
      BEARER14ID                     NUMBER(11),
      BEARER14STATUS                 NUMBER(11),
      BEARER15ID                     NUMBER(11),
      BEARER15STATUS                 NUMBER(11),
      RANGETIME                     DATE
) NOLOGGING
  COMPRESS
  PARTITION BY RANGE
 ( RANGETIME  )
 interval(numtodsinterval(1, 'HOUR'))
 SUBPARTITION BY HASH (imsi)
 SUBPARTITIONS 128
 ( PARTITION
         part_0
        VALUES LESS THAN ( TO_DATE('2016-1-1 08:00:00','YYYY-MM-DD HH24:mi:ss'))
  NOLOGGING );    
-- index
create index IDX_uu_imsi_3 on TB_XDR_IFC_UU(imsi) INITRANS 12 local;  
create index IDX_uu_type_status_3 on TB_XDR_IFC_UU(proceduretype,procedurestatus) INITRANS 12 local;   

DROP TABLE TB_XDR_IFC_X2;   
CREATE TABLE TB_XDR_IFC_X2 (
      PARENTXDRID                   VARCHAR2(32),
      LENGTH                        NUMBER(11),
      CITY                          VARCHAR2(10),
      INTERFACE                     NUMBER(3),
      XDRID                         VARCHAR2(32),
      RAT                           NUMBER(3),      
      IMSI                          VARCHAR2(16),
      IMEI                          VARCHAR2(16),
      MSISDN                        VARCHAR2(32),
      PROCEDURETYPE                 NUMBER(3),
      PROCEDURESTARTTIME            NUMBER(20), -- DATE,
      PROCEDUREENDTIME              NUMBER(20), -- DATE,
      PROCEDURESTATUS               NUMBER(3),
      CELLID                        NUMBER(11),  --SOURCECELLID
      TARGETCELLID                  NUMBER(11),
      ENBID                         NUMBER(11),  --SOURCEENBID
      TARGETENBID                   NUMBER(11),
      MMEUES1APID                   NUMBER(11),
      MMEGROUPID                    NUMBER(11),
      MMECODE                       NUMBER(11),
      REQUESTCAUSE                  NUMBER(11),
      FAILURECAUSE                  NUMBER(11),
      EPSBEARERNUMBER               NUMBER(11),
      BEARER0ID                     NUMBER(11),
      BEARER0STATUS                 NUMBER(11),
      BEARER1ID                     NUMBER(11),
      BEARER1STATUS                 NUMBER(11),
      BEARER2ID                     NUMBER(11),
      BEARER2STATUS                 NUMBER(11),
      BEARER3ID                     NUMBER(11),
      BEARER3STATUS                 NUMBER(11),
      BEARER4ID                     NUMBER(11),
      BEARER4STATUS                 NUMBER(11),
      BEARER5ID                     NUMBER(11),
      BEARER5STATUS                 NUMBER(11),
      BEARER6ID                     NUMBER(11),
      BEARER6STATUS                 NUMBER(11),
      BEARER7ID                     NUMBER(11),
      BEARER7STATUS                 NUMBER(11),
      BEARER8ID                     NUMBER(11),
      BEARER8STATUS                 NUMBER(11),
      BEARER9ID                     NUMBER(11),
      BEARER9STATUS                 NUMBER(11),
      BEARER10ID                     NUMBER(11),
      BEARER10STATUS                 NUMBER(11),
      BEARER11ID                     NUMBER(11),
      BEARER11STATUS                 NUMBER(11),
      BEARER12ID                     NUMBER(11),
      BEARER12STATUS                 NUMBER(11),
      BEARER13ID                     NUMBER(11),
      BEARER13STATUS                 NUMBER(11),
      BEARER14ID                     NUMBER(11),
      BEARER14STATUS                 NUMBER(11),
      BEARER15ID                     NUMBER(11),
      BEARER15STATUS                 NUMBER(11),
      RANGETIME                     DATE
) NOLOGGING
  COMPRESS
  PARTITION BY RANGE
 ( RANGETIME  )
 interval(numtodsinterval(1, 'HOUR'))
 SUBPARTITION BY HASH (imsi)
 SUBPARTITIONS 128
 ( PARTITION
         part_0
        VALUES LESS THAN ( TO_DATE('2016-1-1 08:00:00','YYYY-MM-DD HH24:mi:ss'))
  NOLOGGING );
  
create index IDX_x2_imsi3 on TB_XDR_IFC_X2(imsi) INITRANS 12 local;  

DROP TABLE TB_XDR_IFC_S1MME;   
CREATE TABLE TB_XDR_IFC_S1MME (
      PARENTXDRID                   VARCHAR2(32),
      LENGTH                        NUMBER(11),
      CITY                          VARCHAR2(10),
      INTERFACE                     NUMBER(3),
      XDRID                         VARCHAR2(32),
      RAT                           NUMBER(3),      
      IMSI                          VARCHAR2(16),
      IMEI                          VARCHAR2(16),
      MSISDN                        VARCHAR2(32),   
      PROCEDURETYPE                 NUMBER(3),
      PROCEDURESTARTTIME            NUMBER(20),
      PROCEDUREENDTIME              NUMBER(20),
      PROCEDURESTATUS               NUMBER(11),
      REQUESTCAUSE                  NUMBER(11),
      FAILURECAUSE                  NUMBER(11),
      KEYWORD1                      NUMBER(11),
      KEYWORD2                      NUMBER(11),
      KEYWORD3                      NUMBER(11),
      KEYWORD4                      NUMBER(11),
      MMEUES1APID                   NUMBER(11),
      OLDMMEGROUPID                 NUMBER(11),
      OLDMMECODE                    NUMBER(11),
      OLDMTMSI                      NUMBER(11),
      MMEGROUPID                    NUMBER(11),
      MMECODE                       NUMBER(11),
      MTMSI                         NUMBER(11),
      TMSI                          NUMBER(11),
      USERIPV4                      VARCHAR2(16),
      USERIPV6                      VARCHAR2(50),
      MMEIPADD                      VARCHAR2(50),
      ENBIPADD                      VARCHAR2(50),
      MMEPORT                       NUMBER(11),
      ENBPORT                       NUMBER(11),
      TAC                           NUMBER(11),
      CELLID                        NUMBER(11),
      OTHERTAC                      NUMBER(11),
      OTHERECI                      NUMBER(11),
      APN                           VARCHAR2(50),
      EPSBEARERNUMBER               NUMBER(11),
      BEARER0ID                     NUMBER(11),  
      BEARER0TYPE                   NUMBER(11),
      BEARER0QCI                    NUMBER(11),
      BEARER0STATUS                 NUMBER(11),
      BEARER0REQUESTCAUSE           NUMBER(11),
      BEARER0FAILURECAUSE           NUMBER(11),
      BEARER0ENBGTPTEID             NUMBER(11),
      BEARER0SGWGTPTEID             NUMBER(11),
      BEARER1ID                     NUMBER(11),
      BEARER1TYPE                   NUMBER(11),
      BEARER1QCI                    NUMBER(11),
      BEARER1STATUS                 NUMBER(11),
      BEARER1REQUESTCAUSE           NUMBER(11),
      BEARER1FAILURECAUSE           NUMBER(11),
      BEARER1ENBGTPTEID             NUMBER(11),
      BEARER1SGWGTPTEID             NUMBER(11),
      BEARER2ID                     NUMBER(11),  
      BEARER2TYPE                   NUMBER(11),
      BEARER2QCI                    NUMBER(11),
      BEARER2STATUS                 NUMBER(11),
      BEARER2REQUESTCAUSE           NUMBER(11),
      BEARER2FAILURECAUSE           NUMBER(11),
      BEARER2ENBGTPTEID             NUMBER(11),
      BEARER2SGWGTPTEID             NUMBER(11),
      BEARER3ID                     NUMBER(11),
      BEARER3TYPE                   NUMBER(11),
      BEARER3QCI                    NUMBER(11),
      BEARER3STATUS                 NUMBER(11),
      BEARER3REQUESTCAUSE           NUMBER(11),
      BEARER3FAILURECAUSE           NUMBER(11),
      BEARER3ENBGTPTEID             NUMBER(11),
      BEARER3SGWGTPTEID             NUMBER(11),
      BEARER4ID                     NUMBER(11),  
      BEARER4TYPE                   NUMBER(11),
      BEARER4QCI                    NUMBER(11),
      BEARER4STATUS                 NUMBER(11),
      BEARER4REQUESTCAUSE           NUMBER(11),
      BEARER4FAILURECAUSE           NUMBER(11),
      BEARER4ENBGTPTEID             NUMBER(11),
      BEARER4SGWGTPTEID             NUMBER(11),
      BEARER5ID                     NUMBER(11),
      BEARER5TYPE                   NUMBER(11),
      BEARER5QCI                    NUMBER(11),
      BEARER5STATUS                 NUMBER(11),
      BEARER5REQUESTCAUSE           NUMBER(11),
      BEARER5FAILURECAUSE           NUMBER(11),
      BEARER5ENBGTPTEID             NUMBER(11),
      BEARER5SGWGTPTEID             NUMBER(11),
      BEARER6ID                     NUMBER(11),  
      BEARER6TYPE                   NUMBER(11),
      BEARER6QCI                    NUMBER(11),
      BEARER6STATUS                 NUMBER(11),
      BEARER6REQUESTCAUSE           NUMBER(11),
      BEARER6FAILURECAUSE           NUMBER(11),
      BEARER6ENBGTPTEID             NUMBER(11),
      BEARER6SGWGTPTEID             NUMBER(11),
      BEARER7ID                     NUMBER(11),
      BEARER7TYPE                   NUMBER(11),
      BEARER7QCI                    NUMBER(11),
      BEARER7STATUS                 NUMBER(11),
      BEARER7REQUESTCAUSE           NUMBER(11),
      BEARER7FAILURECAUSE           NUMBER(11),
      BEARER7ENBGTPTEID             NUMBER(11),
      BEARER7SGWGTPTEID             NUMBER(11),
      BEARER8ID                     NUMBER(11),  
      BEARER8TYPE                   NUMBER(11),
      BEARER8QCI                    NUMBER(11),
      BEARER8STATUS                 NUMBER(11),
      BEARER8REQUESTCAUSE           NUMBER(11),
      BEARER8FAILURECAUSE           NUMBER(11),
      BEARER8ENBGTPTEID             NUMBER(11),
      BEARER8SGWGTPTEID             NUMBER(11),
      BEARER9ID                     NUMBER(11),
      BEARER9TYPE                   NUMBER(11),
      BEARER9QCI                    NUMBER(11),
      BEARER9STATUS                 NUMBER(11),
      BEARER9REQUESTCAUSE           NUMBER(11),
      BEARER9FAILURECAUSE           NUMBER(11),
      BEARER9ENBGTPTEID             NUMBER(11),
      BEARER9SGWGTPTEID             NUMBER(11),
      BEARER10ID                     NUMBER(11),  
      BEARER10TYPE                   NUMBER(11),
      BEARER10QCI                    NUMBER(11),
      BEARER10STATUS                 NUMBER(11),
      BEARER10REQUESTCAUSE           NUMBER(11),
      BEARER10FAILURECAUSE           NUMBER(11),
      BEARER10ENBGTPTEID             NUMBER(11),
      BEARER10SGWGTPTEID             NUMBER(11),
      BEARER11ID                     NUMBER(11),
      BEARER11TYPE                   NUMBER(11),
      BEARER11QCI                    NUMBER(11),
      BEARER11STATUS                 NUMBER(11),
      BEARER11REQUESTCAUSE           NUMBER(11),
      BEARER11FAILURECAUSE           NUMBER(11),
      BEARER11ENBGTPTEID             NUMBER(11),
      BEARER11SGWGTPTEID             NUMBER(11),
      BEARER12ID                     NUMBER(11),  
      BEARER12TYPE                   NUMBER(11),
      BEARER12QCI                    NUMBER(11),
      BEARER12STATUS                 NUMBER(11),
      BEARER12REQUESTCAUSE           NUMBER(11),
      BEARER12FAILURECAUSE           NUMBER(11),
      BEARER12ENBGTPTEID             NUMBER(11),
      BEARER12SGWGTPTEID             NUMBER(11),
      BEARER13ID                     NUMBER(11),
      BEARER13TYPE                   NUMBER(11),
      BEARER13QCI                    NUMBER(11),
      BEARER13STATUS                 NUMBER(11),
      BEARER13REQUESTCAUSE           NUMBER(11),
      BEARER13FAILURECAUSE           NUMBER(11),
      BEARER13ENBGTPTEID             NUMBER(11),
      BEARER13SGWGTPTEID             NUMBER(11),                        
      BEARER14ID                     NUMBER(11),  
      BEARER14TYPE                   NUMBER(11),
      BEARER14QCI                    NUMBER(11),
      BEARER14STATUS                 NUMBER(11),
      BEARER14REQUESTCAUSE           NUMBER(11),
      BEARER14FAILURECAUSE           NUMBER(11),
      BEARER14ENBGTPTEID             NUMBER(11),
      BEARER14SGWGTPTEID             NUMBER(11),
      BEARER15ID                     NUMBER(11),
      BEARER15TYPE                   NUMBER(11),
      BEARER15QCI                    NUMBER(11),
      BEARER15STATUS                 NUMBER(11),
      BEARER15REQUESTCAUSE           NUMBER(11),
      BEARER15FAILURECAUSE           NUMBER(11),
      BEARER15ENBGTPTEID             NUMBER(11),
      BEARER15SGWGTPTEID             NUMBER(11),
      RANGETIME                     DATE
) NOLOGGING
  COMPRESS
  PARTITION BY RANGE
 ( RANGETIME  )
 interval(numtodsinterval(1, 'HOUR'))
 SUBPARTITION BY HASH (imsi)
 SUBPARTITIONS 128
 ( PARTITION
         part_0
        VALUES LESS THAN ( TO_DATE('2016-1-1 08:00:00','YYYY-MM-DD HH24:mi:ss'))
  NOLOGGING );
  
create index IDX_S1MME_imsi3 on TB_XDR_IFC_S1MME(imsi,PROCEDURESTARTTIME) INITRANS 12 local;  


DROP TABLE TB_XDR_IFC_SGS;   
CREATE TABLE TB_XDR_IFC_SGS (
      PARENTXDRID                   VARCHAR2(32),
      LENGTH                        NUMBER(11),
      CITY                          VARCHAR2(10),
      INTERFACE                     NUMBER(3),
      XDRID                         VARCHAR2(32),
      RAT                           NUMBER(3),      
      IMSI                          VARCHAR2(16),
      IMEI                          VARCHAR2(16),
      MSISDN                        VARCHAR2(32),
      PROCEDURETYPE                 NUMBER(11),
      PROCEDURESTARTTIME            NUMBER(20),
      PROCEDUREENDTIME              NUMBER(20),
      PROCEDURESTATUS               NUMBER(11),
      SGSCAUSE                      NUMBER(11),
      REJECTCAUSE                   NUMBER(11),
      CPCAUSE                       NUMBER(11),
      RPCAUSE                       NUMBER(11),
      USERIPV4                      VARCHAR2(16),
      USERIPV6                      VARCHAR2(50),
      MMEIPADD                      VARCHAR2(50),
      MSCSERVERIPADD                VARCHAR2(50),
      MMEPORT                       NUMBER(11),
      MSCSERVERPORT                 NUMBER(11),
      SERVICEINDICATOR              NUMBER(11),
      MMENAME                       VARCHAR2(200),
      TMSI                          NUMBER(11),
      NEWLAC                        NUMBER(11),
      OLDLAC                        NUMBER(11),
      TAC                           NUMBER(11),
      CELLID                        NUMBER(11),
      CALLINGID                     VARCHAR2(100),
      VLRNAMELENGTH                 NUMBER(11),
      VLRNAME                       VARCHAR2(255),
      RANGETIME                     DATE
) NOLOGGING
  COMPRESS
  PARTITION BY RANGE
 ( RANGETIME  )
 interval(numtodsinterval(1, 'HOUR'))
 SUBPARTITION BY HASH (imsi)
 SUBPARTITIONS 128
 ( PARTITION
         part_0
        VALUES LESS THAN ( TO_DATE('2016-1-1 08:00:00','YYYY-MM-DD HH24:mi:ss'))
  NOLOGGING );
  
create index ind_sgs_imsi3 on TB_XDR_IFC_SGS(imsi) INITRANS 12 local NOLOGGING;
/**********************************************/
/*1.12 ���ӿ�XDR���ݽṹ:SV�ӿ�               */
/**********************************************/ 
DROP TABLE TB_XDR_IFC_SV;   
CREATE TABLE TB_XDR_IFC_SV (
      PARENTXDRID                   VARCHAR2(32),
      LENGTH                        NUMBER(11),
      CITY                          VARCHAR2(10),
      INTERFACE                     NUMBER(3),
      XDRID                         VARCHAR2(32),
      RAT                           NUMBER(3),      
      IMSI                          VARCHAR2(16),
      IMEI                          VARCHAR2(16),
      MSISDN                        VARCHAR2(32),
      PROCEDURETYPE                 NUMBER(11),
      PROCEDURESTARTTIME            NUMBER(20),
      PROCEDUREENDTIME              NUMBER(20),
      SOURCENEIP                    VARCHAR2(50),
      SOURCENEPORT                  NUMBER(11),
      DESTNEIP                      VARCHAR2(50),
      DESTNEPORT                    NUMBER(11),
      ROAMDIRECTION                 NUMBER(11),
      HOMEMCC                       NUMBER(11),
      HOMEMNC                       NUMBER(11),
      MCC                           NUMBER(11),
      MNC                           NUMBER(11),
      TARGETLAC                     NUMBER(11),
      SOURCETAC                     NUMBER(11),
      SOURCEECI                     NUMBER(30),
      SVFLAGS                       NUMBER(11),
      ULCMSCIP                      VARCHAR2(50),
      DLCMMEIP                      VARCHAR2(50),
      ULCMSCTEID                    NUMBER(11),
      DLCMMETEID                    NUMBER(11),
      STNSR                         VARCHAR2(50),
      TARGETRNCID                   NUMBER(11),
      TARGETCELLID                  NUMBER(11),
      ARP                           NUMBER(11),
      REQUESTRESULT                 NUMBER(11),
      RESULT                        NUMBER(11),
      SVCAUSE                       NUMBER(11),
      POSTFAILURECAUSE              NUMBER(11),
      RESPDELAY                     NUMBER(11),
      SVDELAY                       NUMBER(11),
      RANGETIME                     DATE
) NOLOGGING
  COMPRESS
  PARTITION BY RANGE
 ( RANGETIME  )
 interval(numtodsinterval(1, 'HOUR'))
 SUBPARTITION BY HASH (imsi)
 SUBPARTITIONS 128
 ( PARTITION
         part_0
        VALUES LESS THAN ( TO_DATE('2016-1-1 08:00:00','YYYY-MM-DD HH24:mi:ss'))
  NOLOGGING );  
 create index ind_sv_imsi3 on TB_XDR_IFC_SV(imsi) INITRANS 12 local NOLOGGING;
/****************************************************/
/*1.13 ���ӿ�XDR���ݽṹ:Gm/Mw/Mg/Mi/Mj/ISC�ӿ�     */
/****************************************************/      
DROP TABLE TB_XDR_IFC_GMMWMGMIMJISC;   
CREATE TABLE TB_XDR_IFC_GMMWMGMIMJISC (
      LENGTH                        NUMBER(11),
      CITY                          VARCHAR2(10),
      INTERFACE                     NUMBER(3),
      XDRID                         VARCHAR2(32),
      RAT                           NUMBER(3),      
      IMSI                          VARCHAR2(16),
      IMEI                          VARCHAR2(16),
      MSISDN                        VARCHAR2(32),   
      PROCEDURETYPE                 NUMBER(11),
      PROCEDURESTARTTIME            NUMBER(20),
      PROCEDUREENDTIME              NUMBER(20),
      SERVICETYPE                   NUMBER(11),
      PROCEDURESTATUS               NUMBER(11),
      CALLINGNUMBER                 VARCHAR2(32),
      CALLEDNUMBER                  VARCHAR2(32),
      CALLINGPARTYURI               VARCHAR2(50),
      REQUESTURI                    VARCHAR2(50),
      USERIP                        VARCHAR2(50),
      CALLID                        VARCHAR2(200),
      ICID                          VARCHAR2(100),
      SOURCENEIP                    VARCHAR2(50),
      SOURCENEPORT                  NUMBER(11),
      DESTNEIP                      VARCHAR2(50),
      DESTNEPORT                    NUMBER(11),
      CALLSIDE                      NUMBER(11),
      SOURCEACCESSTYPE              NUMBER(11),
      SOURCEECI                     NUMBER(11),
      SOURCETAC                     NUMBER(11),
      SOURCEIMSI                    VARCHAR2(16),
      SOURCEIMEI                    VARCHAR2(16),
      DESTACCESSTYPE                NUMBER(11),
      DESTECI                       NUMBER(11),
      DESTTAC                       NUMBER(11),
      DESTIMSI                      VARCHAR2(16),
      DESTIMEI                      VARCHAR2(16),
      AUTHTYPE                      NUMBER(11),
      EXPIRESTIMEREQ                NUMBER(20),
      EXPIRESTIMERSP                NUMBER(20),
      CALLINGSDPIPADDR              VARCHAR2(50),
      CALLINGAUDIOSDPPORT           NUMBER(11),
      CALLINGVIDEOSDPPORT           NUMBER(11),
      CALLEDSDPIPADDR               VARCHAR2(50),
      CALLEDAUDIOSDPPORT            NUMBER(11),
      CALLEDVIDEOPORT               NUMBER(11),
      AUDIOCODEC                    NUMBER(11),
      VIDEOCODEC                    NUMBER(11),
      REDIRECTINGPARTYADDRESS       VARCHAR2(64),
      ORIGINALPARTYADDRESS          VARCHAR2(64),
      REDIRECTREASON                NUMBER(11),
      RESPONSECODE                  NUMBER(11),
      FINISHWARNINGCODE             NUMBER(11),
      FINISHREASONPROTOCOL          NUMBER(11),
      FINISHREASONCAUSE             NUMBER(11),
      FIRFAILTIME                   NUMBER(20),
      FIRSTFAILNEIP                 VARCHAR2(50),
      ALERTINGTIME                  NUMBER(20),
      ANSWERTIME                    NUMBER(20),
      RELEASETIME                   NUMBER(20),
      CALLDURATION                  NUMBER(11),
      AUTHREQTIME                   NUMBER(20),
      AUTHRSPTIME                   NUMBER(20),
      STNSR                         VARCHAR2(100),
      ATCFMGMT                      VARCHAR2(100),
      ATUSTI                        VARCHAR2(100),
      CMSISDN                       VARCHAR2(32),
      SSI                           VARCHAR2(32),
      RANGETIME                     DATE
) NOLOGGING
  COMPRESS
  PARTITION BY RANGE
 ( RANGETIME  )
 interval(numtodsinterval(1, 'HOUR'))
 SUBPARTITION BY HASH (imsi)
 SUBPARTITIONS 128
 ( PARTITION
         part_0
        VALUES LESS THAN ( TO_DATE('2016-1-1 08:00:00','YYYY-MM-DD HH24:mi:ss'))
  NOLOGGING );  
  create index ind_gmw_imsi3 on TB_XDR_IFC_GMMWMGMIMJISC(imsi) INITRANS 12 local NOLOGGING;
  
DROP TABLE TB_XDR_IFC_GXRX;   
CREATE TABLE TB_XDR_IFC_GXRX (
      LENGTH                        NUMBER(11),
      CITY                          VARCHAR2(10),
      INTERFACE                     NUMBER(3),
      XDRID                         VARCHAR2(32),
      RAT                           NUMBER(3),      
      IMSI                          VARCHAR2(16),
      IMEI                          VARCHAR2(16),
      MSISDN                        VARCHAR2(32),
      PROCEDURETYPE                 NUMBER(11),
      PROCEDURESTARTTIME            NUMBER(20),
      PROCEDUREENDTIME              NUMBER(20),
      ICID                          VARCHAR2(128),
      ORIGINREALM                   VARCHAR2(44),
      DESTINATIONREALM              VARCHAR2(44),
      ORIGINHOST                    VARCHAR2(64),
      DESTINATIONHOST               VARCHAR2(64),
      SGSNSGWSIGIP                  VARCHAR2(50),
      AFAPPID                       VARCHAR2(50),
      CCREQUESTTYPE                 NUMBER(11),
      RXREQUESTTYPE                 NUMBER(11),
      MEDIATYPE                     NUMBER(11),
      ABORTCAUSE                    NUMBER(11),
      RESULTCODE                    NUMBER(11),
      EXPERIMENTALRESULTCODE        NUMBER(11),
      SESSIONRELEASECAUSE           NUMBER(11),
      RANGETIME                     DATE      
) NOLOGGING
  COMPRESS
  PARTITION BY RANGE
 ( RANGETIME  )
 interval(numtodsinterval(1, 'HOUR'))
SUBPARTITION BY HASH (imsi)
SUBPARTITIONS 128
 ( PARTITION
         part_0
        VALUES LESS THAN ( TO_DATE('2016-1-1 08:00:00','YYYY-MM-DD HH24:mi:ss'))
  NOLOGGING );  
create index ind_gxrx_imsi3 on TB_XDR_IFC_GXRX(imsi) INITRANS 12 local NOLOGGING;

DROP TABLE lte_mro_source;  
create table  lte_mro_source
(
       objectID        VARCHAR2(32) not null ,-- 'OBJECTID',  --����xdrid
       VID             NUMBER(11) not null ,-- 'VID',
       fileFormatVersion VARCHAR2(20) DEFAULT NULL, -- '�ļ���ʽ�汾',
       startTime       DATE not null ,-- '��ʼʱ��',
       endTime         DATE not null ,-- '����ʱ��',
       period          NUMBER(11) ,-- 'ͳ������ ͳ������ �Է��ӱ�ʾͳ�����ڼ����ȡֵ��ΧΪ15���ӻ�15���ӵ�����������15��60��1440����ȱʧ����ʾ�����ڲɼ�����Ϊ0��ʾΪ���������������ݡ�',
       enbID           NUMBER(11) not null ,-- '��վID',
       userLabel       VARCHAR2(40) ,-- '��վ�Ѻ���',
       mrName          VARCHAR2(20) ,-- '���������������� ���������������� �������ݵĵ�һ��ָ��',
       cellID          NUMBER(11) not null ,-- 'С��ID',
       Earfcn          NUMBER(11) ,-- 'Ƶ�� Ƶ�� ������֡��prbʱ��Ч',
       SubFrameNbr     NUMBER(11) ,-- '��֡ ��֡ ������֡��prbʱ��Ч',
       PRBNbr          NUMBER(11) ,-- 'PRB���� PRB���� ����prbʱ��Ч',
       MmeUeS1apId     NUMBER(11) ,-- 'MME MME UE S1Ӧ�ó����ʶ ����������Ч',
       MmeGroupId      NUMBER(11) ,-- 'MME���ʶ MME���ʶ ����������Ч',
       MmeCode         NUMBER(11) ,-- 'MME�� MME�� ����������Ч',
       meaTime         DATE ,-- '��������UE����������ʱ�� ��������UE����������ʱ�� ����������Ч',
       EventType       VARCHAR2(10) ,-- '�������ݲ����¼����� �������ݲ����¼����� ����36.331������¼����ͣ�ȡֵΪö���ͣ�A1, A2, A3, A4, A5, A6, B1, B2��',
       gridcenterLongitude   FLOAT(24),-- 'դ�񾭶�',
       gridcenterLatitude    FLOAT(24),-- 'դ��γ��',
       kpi1            NUMBER(11) ,-- 'ָ��1',
       kpi2            NUMBER(11) ,-- 'ָ��2',
       kpi3            NUMBER(11) ,-- 'ָ��3',
       kpi4            NUMBER(11) ,-- 'ָ��4',
       kpi5            NUMBER(11) ,-- 'ָ��5',
       kpi6            NUMBER(11) ,-- 'ָ��6',
       kpi7            NUMBER(11) ,-- 'ָ��7',
       kpi8            NUMBER(11) ,-- 'ָ��8',
       kpi9            NUMBER(11) ,-- 'ָ��9',
       kpi10           NUMBER(11) ,-- 'ָ��10',
       kpi11           NUMBER(11) ,-- 'ָ��11',
       kpi12           NUMBER(11) ,-- 'ָ��12',
       kpi13           NUMBER(11) ,-- 'ָ��13',
       kpi14           NUMBER(11) ,-- 'ָ��14',
       kpi15           NUMBER(11) ,-- 'ָ��15',
       kpi16           NUMBER(11) ,-- 'ָ��16',
       kpi17           NUMBER(11) ,-- 'ָ��17',
       kpi18           NUMBER(11) ,-- 'ָ��18',
       kpi19           NUMBER(11) ,-- 'ָ��19',
       kpi20           NUMBER(11) ,-- 'ָ��20',
       kpi21           NUMBER(11) ,-- 'ָ��21',
       kpi22           NUMBER(11) ,-- 'ָ��22',
       kpi23           NUMBER(11) ,-- 'ָ��23',
       kpi24           NUMBER(11) ,-- 'ָ��24',
       kpi25           NUMBER(11) ,-- 'ָ��25',
       kpi26           NUMBER(11) ,-- 'ָ��26',
       kpi27           NUMBER(11) ,-- 'ָ��27',
       kpi28           NUMBER(11) ,-- 'ָ��28',
       kpi29           NUMBER(11) ,-- 'ָ��29',
       kpi30           NUMBER(11) ,-- 'ָ��30',
       kpi31           NUMBER(11) ,-- 'ָ��31',
       kpi32           NUMBER(11) ,-- 'ָ��32',
       kpi33           NUMBER(11) ,-- 'ָ��33',
       kpi34           NUMBER(11) ,-- 'ָ��34',
       kpi35           NUMBER(11) ,-- 'ָ��35',
       kpi36           NUMBER(11) ,-- 'ָ��36',
       kpi37           NUMBER(11) ,-- 'ָ��37',
       kpi38           NUMBER(11) ,-- 'ָ��38',
       kpi39           NUMBER(11) ,-- 'ָ��39',
       kpi40           NUMBER(11) ,-- 'ָ��40',
       kpi41           NUMBER(11) ,-- 'ָ��41',
       kpi42           NUMBER(11) ,-- 'ָ��42',
       kpi43           NUMBER(11) ,-- 'ָ��43',
       kpi44           NUMBER(11) ,-- 'ָ��44',
       kpi45           NUMBER(11) ,-- 'ָ��45',
       kpi46           NUMBER(11) ,-- 'ָ��46',
       kpi47           NUMBER(11) ,-- 'ָ��47',
       kpi48           NUMBER(11) ,-- 'ָ��48',
       kpi49           NUMBER(11) ,-- 'ָ��49',
       kpi50           NUMBER(11) ,-- 'ָ��50',
       kpi51           NUMBER(11) ,-- 'ָ��51',
       kpi52           NUMBER(11) ,-- 'ָ��52',
       kpi53           NUMBER(11) ,-- 'ָ��53',
       kpi54           NUMBER(11) ,-- 'ָ��54',
       kpi55           NUMBER(11) ,-- 'ָ��55',
       kpi56           NUMBER(11) ,-- 'ָ��56',
       kpi57           NUMBER(11) ,-- 'ָ��57',
       kpi58           NUMBER(11) ,-- 'ָ��58',
       kpi59           NUMBER(11) ,-- 'ָ��59',
       kpi60           NUMBER(11) ,-- 'ָ��60',
       kpi61           NUMBER(11) ,-- 'ָ��61',
       kpi62           NUMBER(11) ,-- 'ָ��62',
       kpi63           NUMBER(11) ,-- 'ָ��63',
       kpi64           NUMBER(11) ,-- 'ָ��64',
       kpi65           NUMBER(11) ,-- 'ָ��65',
       kpi66           NUMBER(11) ,-- 'ָ��66',
       kpi67           NUMBER(11) ,-- 'ָ��67',
       kpi68           NUMBER(11) ,-- 'ָ��68',
       kpi69           NUMBER(11) ,-- 'ָ��69',
       kpi70           NUMBER(11) ,-- 'ָ��70',
       kpi71           NUMBER(11),
       length          NUMBER(11) , -- '����XDR��ռ���ֽ���',
       City             VARCHAR2(20) ,
       XDRType         NUMBER(3) ,
       Interface       NUMBER(5) ,  
       XDRID           VARCHAR2(32) ,
       RAT             NUMBER(3) ,
       IMSI            VARCHAR2(16) ,
       IMEI            VARCHAR2(16) ,
       MSISDN          VARCHAR2(32) ,
       MRType          NUMBER(3) ,
       NeighborCellNumber NUMBER(11) ,
       gsmNeighborCellNumber   NUMBER(11) ,
       tdsNeighborCellNumber   NUMBER(11) ,
       v_enb  NUMBER Generated Always as (mod(enbID,20)),
     mrtime   number(20)
)
COMPRESS 
NOLOGGING
PARTITION BY RANGE (meatime)
interval(numtodsinterval(1, 'HOUR'))
SUBPARTITION BY HASH (imsi)
SUBPARTITIONS 128
(  
  PARTITION part_0 VALUES LESS THAN (TO_DATE('2016-1-1 00:00:00','YYYY-MM-DD HH24:mi:ss'))
    NOLOGGING
    COMPRESS 
)
NOCACHE
NOPARALLEL
NOMONITORING;

/**
��ע��objectIDֵΨһ��VIDֵ��"0 ��1"��"0"����������С��ָ�꣬"1"��ʶΪ��С��ָ�ꡣ
���ڸñ�һ��ֻ��1��С����ָ�꣬���NeighborCellNumber=3��Ҫ���3�м�¼��
*/

-- index
create index lte_mro_source_mrName3 on lte_mro_source(mrName) INITRANS 12 LOCAL NOLOGGING;
create index lte_mro_source_imsi3 on lte_mro_source(imsi) INITRANS 12 LOCAL NOLOGGING;


/****************************************************/
/*ʧ��ԭ��������ķ���    */
/****************************************************/ 
drop table t_pub_option_failcause;
create table t_pub_option_failcause
(
  OPTION_DEFINITION_ID NUMBER(10),
  OPTION_CODE          VARCHAR2(50),
  OPTION_DESC          VARCHAR2(1000)
)nologging;


insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (1,'IMSע��ʧ��');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (2,'����ʧ��');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (3,'Service_Requestʧ��');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (4,'volte����δ��ͨ');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (5,'volte��������');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (6,'volte��Ƶδ��ͨ');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (7,'volte��Ƶ����');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (8,'TAUʧ��');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (9,'4G����');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (10,'4G���л�ʧ��');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (11,'4G_2G/3G�л�ʧ��');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (12,'CSFBʧ��');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (13,'esrvcc�л�ʧ��');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (14,'��������');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (15,'volte����');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (16,'4G���л�');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (17,'4G_2G/3G�л�');
insert into t_pub_option_failcause (OPTION_DEFINITION_ID,OPTION_DESC) values (18,'esrvcc�л�');
