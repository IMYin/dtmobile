package cn.com.dtmobile.hadoop.biz.upordown.constants;

public class EndConstants {
	public static final String U4END = "END4";
	public static final String U2END = "END2";
	public static final String U3END = "END3";
	public static final String STATION_OF_UP_1 = "太原南站之前";
	public static final String STATION_OF_DOWN_1 = "永济站之后";
	public static final String STATION_OF_UP_0 = "永济站之前";
	public static final String STATION_OF_DOWN_0 = "太原站之后";
}
