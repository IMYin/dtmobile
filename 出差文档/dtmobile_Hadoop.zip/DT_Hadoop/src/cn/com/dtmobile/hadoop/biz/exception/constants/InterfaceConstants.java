package cn.com.dtmobile.hadoop.biz.exception.constants;

public class InterfaceConstants {
	public static final String SIP = "SIP";
	public static final String NAS = "NAS";
	public static final String UU = "UU";
	public static final String S1AP = "S1AP";
	public static final String SV = "SV";
	public static final String X2 = "X2";
}
