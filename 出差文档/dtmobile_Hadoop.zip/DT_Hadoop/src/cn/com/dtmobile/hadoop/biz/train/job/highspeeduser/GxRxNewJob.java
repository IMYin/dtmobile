package cn.com.dtmobile.hadoop.biz.train.job.highspeeduser;


public class GxRxNewJob{
	
}