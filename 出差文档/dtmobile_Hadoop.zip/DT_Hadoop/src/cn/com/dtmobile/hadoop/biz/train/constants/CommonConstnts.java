package cn.com.dtmobile.hadoop.biz.train.constants;

public class CommonConstnts {

	public static final Double  slong_dir1 = 113.214038;
	
	public static final Double slat_dir1 = 39.933898;
	
	public static final Double dlong_dir1 = 110.330997;
	
	public static final Double dlat_dir1 = 35.024218;
	
	public static final Double slong = 110.330997; 
	
	public static final Double slat = 35.024218;  
	
	public static final Double dlong = 113.214038;
	
	public static final Double dlat = 39.933898;  
}
