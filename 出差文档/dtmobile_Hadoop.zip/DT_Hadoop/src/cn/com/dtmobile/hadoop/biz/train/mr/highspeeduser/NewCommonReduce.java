package cn.com.dtmobile.hadoop.biz.train.mr.highspeeduser;


public class NewCommonReduce{
	
}