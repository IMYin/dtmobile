package cn.com.dtmobile.hadoop.biz.userHome.constants;

public class UserHomeConstants {
	public static final String Outside4G = "外省4G用户";
	public static final String Inside4G = "内省4G用户";
	public static final String OutsideVolte = "外省Volte用户";
	public static final String InsideVolte = "内省Volte用户";
	public static final String SHANXI = "山西";
}
