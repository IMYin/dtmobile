package cn.com.dtmobile.hadoop.util;


public class Exception4GUtils{
	
}