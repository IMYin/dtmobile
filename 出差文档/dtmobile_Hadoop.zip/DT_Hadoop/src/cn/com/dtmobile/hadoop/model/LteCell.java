package cn.com.dtmobile.hadoop.model;

public class LteCell {

	private String freq1;
	private String pci;
	/**
	 * @return the freq1
	 */
	public String getFreq1() {
		return freq1;
	}
	/**
	 * @param freq1 the freq1 to set
	 */
	public void setFreq1(String freq1) {
		this.freq1 = freq1;
	}
	/**
	 * @return the pci
	 */
	public String getPci() {
		return pci;
	}
	/**
	 * @param pci the pci to set
	 */
	public void setPci(String pci) {
		this.pci = pci;
	}
	
}
